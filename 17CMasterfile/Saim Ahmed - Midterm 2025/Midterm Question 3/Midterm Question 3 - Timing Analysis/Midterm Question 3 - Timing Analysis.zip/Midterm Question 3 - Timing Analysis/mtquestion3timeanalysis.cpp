#include <iostream>
#include <cstdlib>
#include <ctime>
#include <chrono>
#include "EfficientSimpleVector.h"
#include "LinkedList.h"
#include "SimpleVector.h"
#include "Object.h" //Lehr SimpleVector only works with objects.
using namespace std;
using namespace chrono;

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Set the random number seed
    srand(static_cast<unsigned int>(time(0)));
    int sizes[] = {100, 500, 1000, 5000, 10000, 20000, 50000, 100000, 200000};
    

    for (double size : sizes) {   
        SimpleVector<double> arr(size);
        EfficientSimpleVector<double> effArr(size);
        SimpleVector<double> linkArr(size);
    
        auto start = high_resolution_clock::now();
        for (double i = 0 ; i < size ; i++){
            arr.push(i);
        }
        long vecPTime = duration_cast<milliseconds>(high_resolution_clock::now() - start).count();

        
        start = high_resolution_clock::now();
        for (double i = 0 ; i < size ; i++){
            effArr.push(i);
        }

        long vecETime = duration_cast<milliseconds>(high_resolution_clock::now() - start).count();

        
        start = high_resolution_clock::now();
        for (double i = 0 ; i < size ; i++){
            linkArr.push(i);
        }
        long linkTime = duration_cast<milliseconds>(high_resolution_clock::now() - start).count();

        cout << "Simple Vector Push Time: " << vecPTime << endl;
        cout << "Efficient Vector Push Time: " << vecETime << endl;
        cout << "Linked List Push Time: " << linkTime << endl;

    }
    return 0;
}