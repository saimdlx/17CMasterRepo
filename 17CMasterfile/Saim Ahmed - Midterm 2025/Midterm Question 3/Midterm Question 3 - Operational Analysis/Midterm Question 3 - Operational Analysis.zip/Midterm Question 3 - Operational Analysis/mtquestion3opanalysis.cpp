#include <iostream>
#include <cstdlib>
#include <ctime>
#include <chrono>
#include "EfficientSimpleVector.h"
#include "LinkedList.h"
#include "SimpleVector.h"
#include "Object.h" //Lehr SimpleVector only works with objects.
using namespace std;
using namespace chrono;

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Set the random number seed
    srand(static_cast<unsigned int>(time(0)));
    int sizes[] = {100, 500, 1000, 5000, 10000, 20000, 50000, 100000, 200000};
    

    for (double size : sizes) {   
        
        SimpleVector<double> arr(size);
        auto start = high_resolution_clock::now();
        for (double i = 0 ; i < size ; i++){arr.push(i);}
        auto end = high_resolution_clock::now();
        long vecPTime = duration_cast<microseconds>(end - start).count();

        EfficientSimpleVector<double> effArr(size);
        start = high_resolution_clock::now();
        for (double i = 0 ; i < size ; i++){effArr.push(i);}
        end = high_resolution_clock::now();
        long vecETime = duration_cast<microseconds>(end - start).count();

        SimpleVector<double> linkArr(size);
        start = high_resolution_clock::now();
        for (double i = 0 ; i < size ; i++){linkArr.push(i);}
        end = high_resolution_clock::now();
        long linkTime = duration_cast<microseconds>(end - start).count();

        cout << "Input Size" << size << endl;
        cout << "Simple Vector Operation: " << vecPTime << endl;
        cout << "Efficient Vector Operation: " << vecETime << endl;
        cout << "Linked List Push Operation: " << linkTime << endl;

    }
    return 0;
}