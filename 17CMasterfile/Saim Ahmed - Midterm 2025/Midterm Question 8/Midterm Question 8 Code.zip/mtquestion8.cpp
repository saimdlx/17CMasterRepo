#include <iostream>
#include <cmath>
#include <ctime>

using namespace std;

int main() {

    srand(time(0));
    int simNum = 10000;
    int fullNum = 40;
    int prob = 0;

    for (int i = 0 ; i < simNum ; i++){
        int bits[100] = {0};
        for (int j = 0 ; j < fullNum ; j++) {
            int ranDex = rand() % 100;
            while (bits[ranDex] == 1) {
                ranDex = rand() % 100;
            }
            bits[ranDex] = 1;
        }

        bool isFull = true; //reinitialize per run.
        for (int k = 0 ; k < 5 ; k++){
            if (bits[rand() % 100] == 0) {
                isFull = false;
                break;                      //if an empty/false bit is found, break off and try again.
            }
        }
        if (isFull){
            prob++;
        }
    }

    
    cout << "Question 8:" << endl;
    cout << "The probability of 5 randomly filled bits is: " << (static_cast<double>(prob) / simNum) * 100;
    return 0;

}
