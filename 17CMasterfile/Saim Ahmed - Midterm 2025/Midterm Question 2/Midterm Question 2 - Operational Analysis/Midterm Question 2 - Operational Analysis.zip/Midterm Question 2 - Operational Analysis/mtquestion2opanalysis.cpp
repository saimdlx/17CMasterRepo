#include <iostream>
#include <cstdlib>
#include <ctime>
#include <chrono>
using namespace std;
using namespace chrono; //avoids annoying syntax bloat

void bublSrt(int [],int);
void selSort(int [],int);


int main(int argc, char** argv) {
    
    srand(static_cast<unsigned int>(time(0)));
    int sizes[] = {100, 500, 1000, 5000, 10000, 20000, 50000, 100000, 200000};

    for (int x : sizes) {
        int arr[x] = {};
        for (int &n : arr){
            n = rand();
        }
        auto start = high_resolution_clock::now();
        selSort(arr, x);
        auto end = high_resolution_clock::now();
        long sTime = duration_cast<microseconds>(end - start).count();


        for (int &n : arr){
            n = rand();     //just sorting, so randomize for a more controlled run.
        }
        start = high_resolution_clock::now();
        bublSrt(arr, x);
        end = high_resolution_clock::now();
        long bTime = duration_cast<microseconds>(end - start).count();

        cout << "Input Size: " << x << ", " << "Selection Operations: " << sTime << ", " << "Bubble Operations: " << bTime << endl; 
    }

    //Exit
    return 0;
}





void selSort(int a[],int n){
    //Loop and declare variables
    int indx,min;
    for(int pos=0;pos<n-1;pos++){
        //Find the smallest in the list, swap after finding
        min=a[pos];indx=pos;
        for(int i=pos+1;i<n;i++){
            if(a[i]<min){
                min=a[i];
                indx=i;
            }
        }
        //Perform the swap
        a[indx]=a[pos];
        a[pos]=min;
    }
}

void bublSrt(int a[],int n){
    //Keep looping and comparing until no swaps are left
    bool swap;
    do{
        swap=false;
        //Check the list and Swap when necessary
        for(int i=0;i<n-1;i++){
            if(a[i]>a[i+1]){
                int temp=a[i];
                a[i]=a[i+1];
                a[i+1]=temp;
                swap=true;
            }
        }
    }while(swap);
}


