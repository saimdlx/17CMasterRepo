//System Level Libraries
#include <iostream>   //I/O Library
#include <cmath>      //Math Library
using namespace std;  //Library Scope

int fibLoop(int);//Fibonacci Loop
int fibRec(int);//Fibonacci Recursion

int main(int argc, char** argv){

    int nLoop;
    nLoop=40;
    cout<<"Fibonacci Sequence for O(n) function fibLoop"<<endl;
    
    //Display the outputs
    for(int n=0;n<=nLoop;n++){
        cout<<fibLoop(n)<<" ";
    }
    cout<<endl<<endl;
    
    cout<<"Fibonacci Sequence for O(2^n) function fibRec"<<endl;
    //Display the outputs
    for(int n=0;n<=nLoop;n++){
        cout<<fibRec(n)<<" ";
    }
    cout<<endl<<endl;

    return 0;
}

//Time Complexity is O(n)
int fibLoop(int n){
    //Base Case
    if(n<=0)return 0;
    if(n==1)return 1;
    int fim1=1,fim2=0,fi=fim1+fim2;
    for(int i=2;i<n;i++){
        fim2=fim1;
        fim1=fi;
        fi=fim1+fim2;  
    }
    return fi;
}

//Time Complexity is O(2^n)
int fibRec(int n){
    //Base Case
    if(n<=0)return 0;
    if(n==1)return 1;
    //Recursive Representation
    return fibRec(n-1)+fibRec(n-2);
}