#include <iostream>
#include <cmath>

using namespace std;
double recursiveCustom(double x);

int main() {
    cout << "Question 10: " << endl;
    for (double i = 0.1 ; i <= 1 ; i+= 0.1) {
        cout << "Recursive function test at -delta and delta: " << i << " " << recursiveCustom(-i) << " " << recursiveCustom(i) << endl;
    }
}

double recursiveCustom(double x){

    if (abs(x) < 1e-6) {
        return x - ((x*x*x)/6);
    }

    return (2 * recursiveCustom(x / 2)) / (1 + pow(recursiveCustom(x/2),2)); 
}