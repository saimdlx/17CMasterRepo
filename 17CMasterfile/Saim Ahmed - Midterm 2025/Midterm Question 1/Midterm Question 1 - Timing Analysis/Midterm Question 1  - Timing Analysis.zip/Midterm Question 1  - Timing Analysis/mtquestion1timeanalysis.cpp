#include <iostream>
#include <cstdlib>
#include <ctime>
#include <chrono>
using namespace std;
using namespace chrono; //avoids annoying syntax bloat

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Set the random number seed
    srand(static_cast<unsigned int>(time(0)));
    int sizes[] = {100, 500, 1000, 5000, 10000, 20000, 50000, 100000, 200000};

    for (int x : sizes) {
        int arr[x] = {};
        for (int &n : arr){
            n = rand();
        }
        int seek = arr[rand() % x];

        auto start = high_resolution_clock::now();
        //Avoid function call for time analysis
        for (int i = 0 ; i < x ; i++){
            if (arr[i] == seek){
                break;
            }
        }
        auto end = high_resolution_clock::now();
        long lTime = duration_cast<microseconds>(end - start).count();

        start = high_resolution_clock::now();
        int low = 0, high = x - 1, mid;
        while (low <= high) {
            mid = (low + high) / 2;
            if (arr[mid] == seek) break;
            else if (arr[mid] < seek) low = mid + 1;
            else high = mid - 1;
        }
        end = high_resolution_clock::now();
        long bTime = duration_cast<microseconds>(end - start).count();

        cout << "Input Size: " << x << ", " << "Linear Timing: " << lTime << ", " << "Binary Timing: " << bTime << endl; 
    }

    //Exit
    return 0;
}
