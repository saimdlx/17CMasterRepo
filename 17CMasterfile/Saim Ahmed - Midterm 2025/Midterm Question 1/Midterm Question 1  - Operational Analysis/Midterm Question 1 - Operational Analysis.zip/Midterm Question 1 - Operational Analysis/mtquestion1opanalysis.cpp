#include <iostream>
#include <cstdlib>
#include <ctime>
#include <chrono>
using namespace std;
using namespace chrono; //avoids annoying syntax bloat

void swap(int &,int &);
void smlLst(int [],int,int);
void mrkSort(int [],int);
int  linSrch(int [],int, int);
int  binSrch(int [],int, int);

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Set the random number seed
    srand(static_cast<unsigned int>(time(0)));
    int sizes[] = {100, 500, 1000, 5000, 10000, 20000, 50000, 100000, 200000};

    for (int x : sizes) {
        int arr[x] = {};
        for (int &n : arr){
            n = rand();
        }
        int seek = arr[rand() % x];

        auto start = high_resolution_clock::now();
        linSrch(arr, x, seek);
        auto end = high_resolution_clock::now();
        long lTime = duration_cast<microseconds>(end - start).count();

        mrkSort(arr, x);
        start = high_resolution_clock::now();
        binSrch(arr, x, seek);
        end = high_resolution_clock::now();
        long bTime = duration_cast<microseconds>(end - start).count();

        cout << "Input Size: " << x << ", " << "Linear Operations: " << lTime << ", " << "Binary Operations: " << bTime << endl; 
    }

    //Exit
    return 0;
}
int binSrch(int a[],int n, int val){
    //Initialize end points which are indexes
    int lowEnd=0;
    int highEnd=n-1;
    
    //Loop until value found not indexes
    do{
        int middle=(highEnd+lowEnd)/2;
        if(val==a[middle])return middle;
        else if(val>a[middle])lowEnd=middle+1;
        else highEnd=middle-1;
    }while(lowEnd<=highEnd);
    
    //Not found
    return -1;
}

int linSrch(int a[],int n, int val){
    for(int indx=0;indx<n;indx++){
        if(val==a[indx])return indx;
    }
    return -1;
}

void mrkSort(int a[],int n){
    for(int pos=0;pos<n-1;pos++){
        smlLst(a,n,pos);
    }
}

void smlLst(int a[],int n,int pos){
    for(int i=pos+1;i<n;i++){
        if(a[pos]>a[i]){
            swap(a[pos],a[i]);
        }
    }
}

void swap(int &a,int &b){
    int temp=a;
    a=b;
    b=temp;
}