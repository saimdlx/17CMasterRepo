#include <iostream>
#include <cmath>

using namespace std;
double powN(int x, int n);
double powLog(int x, int n);

int main() {

    cout << "Power 10^2 in O(n): " << powN(10.0, 2.0) << endl;
    cout << "Power 10^2 in O(Logn): " << powLog(10.0, 2.0) << endl;
    cout << endl;
    cout << "Power 10^3 in O(n): " << powN(10.0, 3.0) << endl;
    cout << "Power 10^3 in O(Logn): " << powLog(10.0, 3.0) << endl;
    

}

double powN(int x, int n) {
    if (n == 0) {
        return 1;
    }

    return x * powN(x, n - 1);
}


double powLog(int x, int n) {


    if (n == 0) {
        return 1;
    }
    double powHalf = powLog(x, n/2);

    return (n % 2 == 0) ? powHalf * powHalf : x * powHalf * powHalf;

}