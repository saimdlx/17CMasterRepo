#include <iostream>
#include <cmath>
#include <ctime>

using namespace std;

int main(){
    srand(time(0));
    int crcnt[4] = {0};
    int simNum = 10000;

    for (int i = 0 ; i < simNum ; i++){
        int ranFace[13] = {0};
        for (int j = 0 ; j < 4 ; j++){
            ranFace[rand() % 13]++;     //element at that random number plus plus to simulate x of a kind or pairs.
        }

        int pairs = 0;
        int three = 0;
        int four = 0;
        for (int x = 0; x < 13 ; x++){
            if (ranFace[x] == 2){  
                pairs++;
            }
            else if(ranFace[x] == 3) {
                three++;
            }
            else if(ranFace[x] == 4) {
                four++;
            }
        }

        if(pairs == 1) {crcnt[0]++;}        /*increment card count element at index of desired number to store*/
        else if(pairs == 2) {crcnt[1]++;}
        else if(three) {crcnt[2]++;}
        else if(four) {crcnt[3]++;}
    }

    cout << "The following probabilities for the requested results: " << endl;
    cout << "One Pair: " << (static_cast<double>(crcnt[0]) / simNum) * 100 << "%" << endl;
    cout << "Two Pair: " << (static_cast<double>(crcnt[1]) / simNum) * 100 << "%" << endl;
    cout << "Three of a kind: " << (static_cast<double>(crcnt[2]) / simNum) * 100 << "%" << endl;
    cout << "Four of a kind: " << (static_cast<double>(crcnt[3]) / simNum) * 100 << "%" << endl;

}