#include <iostream>
#include <set>
#include <map>
#include <algorithm>
/*
    to save myself from the clusterf*ck of a headache 
    i COULD induce if i didn't use it, i'll use count_if 
    statements to find modes.
*/

using namespace std;

int *sMode(const int *array,int arySize){
    set<int> vals(array, array + arySize);
    int freq = 0, modes = 0;
    for (int v : vals) {
        int count = count_if(array, array + arySize, [v](int prse) {
            return prse == v;   //if the current argument is equal to the value in the set, count it.
        });
        if(count > freq) {
            freq = count;
            modes = 1;}
        else if (count == freq){modes++;}
    }
    int *modeAry = new int[modes+2];
    modeAry[0] = modes;
    modeAry[1] = freq+1;
    int indx = 2;
    for (int v : vals){
        int count = count_if(array, array + arySize, [v](int prse) {
            return prse == v;   //if the current argument is equal to the value in the set, count it.
        });
        if (count == freq){modeAry[indx++] = v;}
    }
    return modeAry; 
}

int *mMode(const int *array,int arySize){
    map<int, int> valMap;
    int freq = 0;
    for (int i = 0; i < arySize; i++){
        freq = max(freq, valMap[array[i]]++);
    }
    int modes = count_if(valMap.begin(), valMap.end(), [freq](auto &prse) {return prse.second == freq;}); //second value from map.
    int *modeAry = new int[modes+2];
    modeAry[0] = modes;
    modeAry[1] = freq+1;
    int indx = 2;
    for (auto &[v, f] : valMap){
        if (f == freq) {modeAry[indx++] = v;}
    }
    return modeAry; 
}

void prntMod(int *ary){
    cout<<endl;
    cout<<"The number of modes = "<<
            ary[0]<<endl;
    cout<<"The max Frequency = "<<
            ary[1]<<endl;
    if(ary[0]==0){
        cout<<"The mode set = {null}"<<endl;
        return;
    }
    cout<<"The mode set = {";
    for(int i=2;i<ary[0]+1;i++){
        cout<<ary[i]<<",";
    }
    cout<<ary[ary[0]+1]<<"}"<<endl;
}
//Execution begins here
int main(int argc, char*argv[]) {
    int ary[] = {1,1,2,3,4,5,5,7,7,7,1,2,3,1,4,51,2,3,4,1};
    int aSize = sizeof(ary) / sizeof(ary[0]);
    int *setRes = sMode(ary, aSize);
    prntMod(setRes);
    delete[] setRes;
    int *mapRes = mMode(ary, aSize);
    prntMod(mapRes);
    delete[] mapRes;
    return 0;
}