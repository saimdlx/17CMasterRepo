#include <iostream>
#include <cmath>

using namespace std;

double S(double x);
double C(double x);
double epsilon = 1e-6;

int main(){
    /*
        These recursive statements, despite being so small, will take a LONG time because of our
        conditionals.
    */ 

    for (double i = 0.1 ; i < atan(1) ; i+=0.1){
        cout << "C(2x): " << C(i) << "\n" << "S(2x): " << S(i) << endl;
    }
    
}

double S(double x){

    if (abs(x) < epsilon){
        return 1 + pow(x,2)/2.0;
    }
    double cx = C(x/2);
    double sx = S(x/2);
    //to return c^2(x) * s^2(x) / c^2(x) - s^2(x)
    return ((cx * cx) * (sx * sx)) / ((cx * cx) - (sx * sx));

}

double C(double x) {
    if (abs(x) < epsilon){
        return (1.0 / x) + (x / 6.0);
    }

    return (C(x / 2.0) * S(x / 2.0)) / 2.0;
}